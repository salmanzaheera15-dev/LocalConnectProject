# LocalConnect – Local Marketplace (No OTP Version)

Mobile-first web app that connects local buyers with vendors.
Access is restricted to **signed-in buyers** for placing orders.

- Frontend: HTML5, CSS3, JavaScript
- Backend: Node.js + Express.js
- Auth: Email + password (bcrypt + JWT)
- DSA: Hash Map (`Map`), Queue (`OrderQueue`), Quick Sort (custom)

## Run Backend

```bash
cd backend
npm install
npm start
```

Backend URL: http://localhost:5000

## Run Frontend

Option 1 (recommended): VS Code Live Server  
- Open `frontend/index.html` and choose **“Open with Live Server”**.

Option 2: Double-click `frontend/index.html` and open in a browser.

## Demo Flow

1. Register a user as **buyer** (name, email, password).
2. Sign in with that account.
3. Status bar shows: `Signed in as <name> (buyer)` and **Place Order** button becomes active.
4. Browse products, use the sort dropdown (Quick Sort) to reorder by distance/price.
5. Add products to cart and place order (only buyers can place orders).
6. On Vendor tab, enter a vendor ID (e.g. `v1`) and click **Load My Orders** to see the FIFO queue.

## DSA Usage

- `frontend/app.js`
  - `productsById = new Map()` → Hash Map for O(1) product lookup.
  - `quickSortProducts()` → custom Quick Sort for distance/price sorting.
- `backend/dsa/orderQueue.js`
  - `OrderQueue` → Queue for vendor orders (FIFO).
