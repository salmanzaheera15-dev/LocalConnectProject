const API_BASE = "http://localhost:5000";

// ----- DSA: Quick Sort for products -----
function quickSortProducts(arr, key, ascending = true) {
  if (arr.length <= 1) return arr;
  const pivot = arr[arr.length - 1];
  const left = [];
  const right = [];
  for (let i = 0; i < arr.length - 1; i++) {
    const condition = ascending
      ? arr[i][key] <= pivot[key]
      : arr[i][key] >= pivot[key];
    if (condition) left.push(arr[i]);
    else right.push(arr[i]);
  }
  return [
    ...quickSortProducts(left, key, ascending),
    pivot,
    ...quickSortProducts(right, key, ascending)
  ];
}

// ----- DSA: Hash Map for products & cart -----
const productsById = new Map();
const cart = new Map();

let authToken = null;
let currentUser = null;

// DOM references
const productsListEl = document.getElementById("productsList");
const cartItemsEl = document.getElementById("cartItems");
const cartTotalEl = document.getElementById("cartTotal");
const sortSelectEl = document.getElementById("sortSelect");
const refreshProductsBtn = document.getElementById("refreshProductsBtn");
const placeOrderBtn = document.getElementById("placeOrderBtn");
const statusBar = document.getElementById("statusBar");

const tabButtons = document.querySelectorAll(".tab-button");
const tabContents = document.querySelectorAll(".tab-content");

const vendorIdInput = document.getElementById("vendorIdInput");
const loadVendorOrdersBtn = document.getElementById("loadVendorOrdersBtn");
const vendorOrdersEl = document.getElementById("vendorOrders");

const regName = document.getElementById("regName");
const regEmail = document.getElementById("regEmail");
const regPassword = document.getElementById("regPassword");
const regRole = document.getElementById("regRole");
const registerBtn = document.getElementById("registerBtn");
const registerHint = document.getElementById("registerHint");

const loginEmail = document.getElementById("loginEmail");
const loginPassword = document.getElementById("loginPassword");
const loginBtn = document.getElementById("loginBtn");
const loginHint = document.getElementById("loginHint");

// ----- Auth helpers -----
function setAuth(token, user) {
  authToken = token;
  currentUser = user;
  if (token) {
    localStorage.setItem("lc_token", token);
    localStorage.setItem("lc_user", JSON.stringify(user));
  } else {
    localStorage.removeItem("lc_token");
    localStorage.removeItem("lc_user");
  }
  updateStatusBar();
}

function loadAuthFromStorage() {
  const t = localStorage.getItem("lc_token");
  const u = localStorage.getItem("lc_user");
  if (t && u) {
    authToken = t;
    try {
      currentUser = JSON.parse(u);
    } catch {
      currentUser = null;
    }
  }
  updateStatusBar();
}

function updateStatusBar() {
  if (!currentUser) {
    statusBar.textContent = "Not logged in.";
    placeOrderBtn.disabled = true;
    placeOrderBtn.textContent = "Sign in as buyer to order";
    return;
  }

  statusBar.textContent =
    `Signed in as ${currentUser.name} (${currentUser.role})`;

  if (currentUser.role === "buyer") {
    placeOrderBtn.disabled = false;
    placeOrderBtn.textContent = "Place Order";
  } else {
    placeOrderBtn.disabled = true;
    placeOrderBtn.textContent = "Only buyers can place orders";
  }
}

// ----- Tabs -----
tabButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    const target = btn.dataset.tab;
    tabButtons.forEach(b => b.classList.remove("active"));
    tabContents.forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(target).classList.add("active");
  });
});

// ----- Auth: Register / Login -----
registerBtn.addEventListener("click", async () => {
  registerHint.textContent = "";
  const name = regName.value.trim();
  const email = regEmail.value.trim();
  const password = regPassword.value;
  const role = regRole.value;

  if (!name || !email || !password) {
    registerHint.textContent = "Please fill in all fields.";
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/api/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password, role })
    });
    const data = await res.json();
    registerHint.textContent = data.message || "";
  } catch (err) {
    console.error("Register error:", err);
    registerHint.textContent = "Registration failed. Check console.";
  }
});

loginBtn.addEventListener("click", async () => {
  loginHint.textContent = "";
  const email = loginEmail.value.trim();
  const password = loginPassword.value;

  if (!email || !password) {
    loginHint.textContent = "Please fill in both fields.";
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) {
      loginHint.textContent = data.message || "Login failed.";
      return;
    }
    const user = {
      email,
      role: data.role,
      name: data.name || email.split("@")[0]
    };
    setAuth(data.token, user);
    loginHint.textContent = "Login successful.";
  } catch (err) {
    console.error("Login error:", err);
    loginHint.textContent = "Login failed. Check console.";
  }
});

// ----- Products & Cart -----
let productsArray = [];

async function fetchProducts() {
  productsById.clear();
  productsArray = [];
  try {
    const res = await fetch(`${API_BASE}/api/products`);
    const data = await res.json();
    data.forEach(p => {
      productsArray.push(p);
      productsById.set(p.id, p);
    });
    renderProducts();
  } catch (err) {
    console.error("Error fetching products:", err);
  }
}

function renderProducts() {
  productsListEl.innerHTML = "";
  let listToRender = [...productsArray];
  const sortValue = sortSelectEl.value;
  if (sortValue === "distance") {
    listToRender = quickSortProducts(listToRender, "distanceKm", true);
  } else if (sortValue === "priceLowHigh") {
    listToRender = quickSortProducts(listToRender, "price", true);
  } else if (sortValue === "priceHighLow") {
    listToRender = quickSortProducts(listToRender, "price", false);
  }
  listToRender.forEach(p => {
    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <h3>${p.name}</h3>
      <div class="meta">${p.category} · <span class="badge">${p.vendorName}</span></div>
      <div class="meta">Distance: ${p.distanceKm.toFixed(1)} km</div>
      <div class="price">Price: Rs ${p.price}</div>
      <p style="font-size:0.85rem;margin:0.3rem 0 0.5rem;">${p.description}</p>
      <button data-product-id="${p.id}">Add to Cart</button>
    `;
    card.querySelector("button").addEventListener("click", () => addToCart(p.id));
    productsListEl.appendChild(card);
  });
}

function addToCart(productId) {
  const product = productsById.get(productId);
  if (!product) return;
  if (cart.has(productId)) {
    const entry = cart.get(productId);
    entry.qty += 1;
    cart.set(productId, entry);
  } else {
    cart.set(productId, { product, qty: 1 });
  }
  renderCart();
}

function renderCart() {
  cartItemsEl.innerHTML = "";
  let total = 0;
  cart.forEach(({ product, qty }) => {
    const itemTotal = product.price * qty;
    total += itemTotal;
    const row = document.createElement("div");
    row.className = "cart-item";
    row.innerHTML = `<span>${product.name} (x${qty})</span><span>Rs ${itemTotal}</span>`;
    cartItemsEl.appendChild(row);
  });
  cartTotalEl.textContent = `Total: Rs ${total}`;
}

// ----- Orders (place + vendor view) -----
async function placeOrder() {
  if (cart.size === 0) {
    alert("Cart is empty.");
    return;
  }
  if (!authToken || !currentUser) {
    alert("You must be signed in as a buyer to place an order.");
    return;
  }
  if (currentUser.role !== "buyer") {
    alert("Only buyers can place orders.");
    return;
  }
  const firstEntry = cart.values().next().value;
  const vendorId = firstEntry.product.vendorId;
  const items = [];
  let totalAmount = 0;
  cart.forEach(({ product, qty }) => {
    items.push({ productId: product.id, name: product.name, qty, price: product.price });
    totalAmount += product.price * qty;
  });
  try {
    const res = await fetch(`${API_BASE}/api/orders`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${authToken}`
      },
      body: JSON.stringify({ vendorId, items, totalAmount })
    });
    const data = await res.json();
    if (!res.ok) {
      alert("Failed to place order: " + (data.message || "Unknown error"));
      return;
    }
    alert("Order placed! It is now in the vendor's queue.");
    cart.clear();
    renderCart();
  } catch (err) {
    console.error("Error placing order:", err);
    alert("Failed to place order. Check console for details.");
  }
}

async function loadVendorOrders() {
  const vendorId = vendorIdInput.value.trim();
  if (!vendorId) {
    alert("Please enter a vendor ID (e.g., v1).");
    return;
  }
  try {
    const res = await fetch(`${API_BASE}/api/orders/vendor/${vendorId}`);
    const data = await res.json();
    vendorOrdersEl.innerHTML = "";
    if (!data.orders || data.orders.length === 0) {
      vendorOrdersEl.innerHTML = "<p>No orders in your queue yet.</p>";
      return;
    }
    data.orders.forEach(order => {
      const card = document.createElement("article");
      card.className = "card";
      const itemsList = order.items.map(i => `${i.name} (x${i.qty})`).join(", ");
      card.innerHTML = `
        <h3>Order #${order.id}</h3>
        <div class="meta">Customer: ${order.customerName}</div>
        <div class="meta">Status: <span class="badge">${order.status}</span></div>
        <div class="meta">Total: Rs ${order.totalAmount}</div>
        <p style="font-size:0.85rem;margin:0.4rem 0;">Items: ${itemsList}</p>
      `;
      vendorOrdersEl.appendChild(card);
    });
  } catch (err) {
    console.error("Error loading vendor orders:", err);
  }
}

// ----- Event listeners -----
refreshProductsBtn.addEventListener("click", fetchProducts);
sortSelectEl.addEventListener("change", renderProducts);
placeOrderBtn.addEventListener("click", placeOrder);
loadVendorOrdersBtn.addEventListener("click", loadVendorOrders);

// ----- Init -----
loadAuthFromStorage();
fetchProducts();
