export class OrderQueue {
  constructor() {
    this.items = [];
  }

  enqueue(order) {
    this.items.push(order);
  }

  dequeue() {
    return this.items.shift();
  }

  peek() {
    return this.items[0];
  }

  isEmpty() {
    return this.items.length === 0;
  }

  toArray() {
    return [...this.items];
  }
}
