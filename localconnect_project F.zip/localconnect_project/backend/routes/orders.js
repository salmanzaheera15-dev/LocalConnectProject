import express from "express";
import { OrderQueue } from "../dsa/orderQueue.js";
import { authRequired, buyerOnly } from "../middleware/auth.js";

const router = express.Router();

// Map<vendorId, OrderQueue>
const vendorOrderQueues = new Map();

function getQueue(vendorId) {
  if (!vendorOrderQueues.has(vendorId)) {
    vendorOrderQueues.set(vendorId, new OrderQueue());
  }
  return vendorOrderQueues.get(vendorId);
}

// Place order (only logged-in buyers)
router.post("/", authRequired, buyerOnly, (req, res) => {
  const { vendorId, items, totalAmount } = req.body;
  const customerName = req.user.name;

  if (!vendorId || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: "Invalid order payload" });
  }

  const newOrder = {
    id: "o_" + Date.now(),
    customerName,
    vendorId,
    items,
    totalAmount,
    status: "pending",
    createdAt: new Date().toISOString()
  };

  const queue = getQueue(vendorId);
  queue.enqueue(newOrder);

  return res.status(201).json({
    message: "Order placed and added to vendor queue (FIFO).",
    order: newOrder
  });
});

// Vendor view: see queue
router.get("/vendor/:vendorId", (req, res) => {
  const { vendorId } = req.params;
  const queue = getQueue(vendorId);

  res.json({
    vendorId,
    orders: queue.toArray()
  });
});

export default router;
