import express from "express";

const router = express.Router();

const products = [
  {
    id: "p1",
    name: "Fresh Vegetables Pack",
    category: "Groceries",
    price: 500,
    vendorId: "v1",
    vendorName: "Sara's Home Store",
    distanceKm: 1.2,
    description: "Locally sourced mixed vegetables for daily cooking."
  },
  {
    id: "p2",
    name: "Home-Cooked Biryani",
    category: "Meals",
    price: 350,
    vendorId: "v2",
    vendorName: "Auntie's Kitchen",
    distanceKm: 0.8,
    description: "Family-style chicken biryani, enough for one person."
  },
  {
    id: "p3",
    name: "Stationery Combo Pack",
    category: "Stationery",
    price: 250,
    vendorId: "v3",
    vendorName: "Local Stationers",
    distanceKm: 2.1,
    description: "Notebooks, pens and basic stationery for students."
  }
];

router.get("/", (req, res) => {
  res.json(products);
});

export default router;
