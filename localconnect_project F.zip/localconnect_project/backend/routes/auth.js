import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "localconnect_dev_secret";
const users = []; // in-memory store

// REGISTER
router.post("/register", async (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: "Name, email and password are required" });
  }

  const existing = users.find(u => u.email === email);
  if (existing) {
    return res.status(400).json({ message: "User with this email already exists" });
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const newUser = {
    id: "u_" + Date.now(),
    name,
    email,
    passwordHash,
    role: role === "vendor" ? "vendor" : "buyer"
  };

  users.push(newUser);

  return res.status(201).json({
    message: "Registered successfully. You can now log in."
  });
});

// LOGIN
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  const user = users.find(u => u.email === email);
  if (!user) {
    return res.status(401).json({ message: "Invalid email or password" });
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    return res.status(401).json({ message: "Invalid email or password" });
  }

  const token = jwt.sign(
    {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    },
    JWT_SECRET,
    { expiresIn: "1h" }
  );

  return res.json({
    message: "Login successful",
    token,
    role: user.role,
    name: user.name
  });
});

// DEBUG ONLY
router.get("/_debug_users", (req, res) => {
  res.json(users);
});

export default router;
